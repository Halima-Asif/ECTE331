package projectPartA;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Main {

    static long initialTime = System.currentTimeMillis(); // Record the start time for runtime measurement
    public static short[][] grayImageMatrix;
    public static int imageWidth;
    public static int imageHeight;
    private static BufferedImage originalImage;
    private static BufferedImage patternImage;
    private static boolean[][] visitedMatrix;

    public static void main(String[] args) throws IOException {
        // Define paths to the source and template images
        String originalImagePath = "TenCardG.jpg";
        String patternImagePath = "Template.jpg";

        // Read and convert the images to grayscale
        originalImage = ImageIO.read(new File(originalImagePath));
        short[][] originalGray = convertToGrayScale(originalImagePath);
        patternImage = ImageIO.read(new File(patternImagePath));
        short[][] patternGray = convertToGrayScale(patternImagePath);

        // Find all matching regions of the template in the source image
        Rectangle[] matchRectangles = locateAllMatches(patternGray, originalGray);

        // Draw rectangles around all matched regions
        for (Rectangle rect : matchRectangles) {
            drawMatchRectangle(originalImage, rect);
        }

        // Save the result image with rectangles drawn on it
        String resultImagePath = "Output.jpg";
        ImageIO.write(originalImage, "jpg", new File(resultImagePath));
        System.out.println("Check " + resultImagePath + " to view the image");

        // Display the result image in a window
        showImage(resultImagePath, "Source Image with Rectangles");

        // Output the number of matches found and their locations
        System.out.println("Total Number of Matches Found: " + matchRectangles.length);
        for (Rectangle rect : matchRectangles) {
            System.out.println("Match was found at: (" + rect.x + ", " + rect.y + ")");
        }

        // Measure and output the total runtime
        long endTime = System.currentTimeMillis();
        long totalTime = endTime - initialTime;
        System.out.println("Total runtime time: " + totalTime + " milliseconds");
    }

    // Convert an image to grayscale
    public static short[][] convertToGrayScale(String fileName) throws IOException {
        BufferedImage image = ImageIO.read(new File(fileName));
        imageWidth = image.getWidth();
        imageHeight = image.getHeight();

        byte[] pixelArray = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        grayImageMatrix = new short[imageHeight][imageWidth];
        visitedMatrix = new boolean[imageHeight][imageWidth];

        int pixelIndex, red, green, blue;
        for (int row = 0; row < imageHeight; row++) {
            for (int col = 0; col < imageWidth; col++) {
                pixelIndex = 3 * (row * imageWidth + col);
                red = pixelArray[pixelIndex] & 0xff;
                green = pixelArray[pixelIndex + 1] & 0xff;
                blue = pixelArray[pixelIndex + 2] & 0xff;
                grayImageMatrix[row][col] = (short) Math.round(0.299 * red + 0.587 * green + 0.114 * blue);
            }
        }
        return grayImageMatrix;
    }

    // Check if a region of the image has been visited
    public static boolean hasBeenVisited(int row, int col, int patternHeight, int patternWidth) {
        for (int i = Math.max(0, row); i < Math.min(row + patternHeight, imageHeight); i++) {
            for (int j = Math.max(0, col); j < Math.min(col + patternWidth, imageWidth); j++) {
                if (visitedMatrix[i][j]) {
                    return true;
                }
            }
        }
        return false;
    }

    // Mark a region of the image as visited
    public static void setVisited(int row, int col, int patternHeight, int patternWidth) {
        for (int i = Math.max(0, row); i < Math.min(row + patternHeight, imageHeight); i++) {
            for (int j = Math.max(0, col); j < Math.min(col + patternWidth, imageWidth); j++) {
                visitedMatrix[i][j] = true;
            }
        }
    }

    // Find all matches of the template in the source image
    public static Rectangle[] locateAllMatches(short[][] patternImage, short[][] originalImage) {
        int originalHeight = originalImage.length;
        int originalWidth = originalImage[0].length;
        int patternHeight = patternImage.length;
        int patternWidth = patternImage[0].length;
        double minimumDifference = Double.MAX_VALUE;
        int patternArea = patternHeight * patternWidth;
        List<Rectangle> matchList = new ArrayList<Rectangle>();

        double[][] differenceMatrix = new double[originalHeight - patternHeight + 1][originalWidth - patternWidth + 1];

        for (int i = 0; i <= originalHeight - patternHeight; i++) {
            for (int j = 0; j <= originalWidth - patternWidth; j++) {
                double absoluteDifference = 0;

                if (hasBeenVisited(i, j, patternHeight, patternWidth)) {
                    continue;
                }

                for (int k = 0; k < patternHeight; k++) {
                    for (int l = 0; l < patternWidth; l++) {
                        absoluteDifference += Math.abs(originalImage[i + k][j + l] - patternImage[k][l]);
                    }
                }
                absoluteDifference /= patternArea;
                differenceMatrix[i][j] = absoluteDifference;

                if (absoluteDifference < minimumDifference) {
                    minimumDifference = absoluteDifference;
                }
            }
        }

        double threshold = 10 * minimumDifference;

        for (int i = 0; i <= originalHeight - patternHeight; i++) {
            for (int j = 0; j <= originalWidth - patternWidth; j++) {
                if (differenceMatrix[i][j] <= threshold) {
                    matchList.add(new Rectangle(j, i, patternWidth, patternHeight));
                    setVisited(i, j, patternHeight, patternWidth);
                }
            }
        }

        return matchList.toArray(new Rectangle[0]);
    }

    // Draw a rectangle around the matched region
    public static void drawMatchRectangle(BufferedImage image, Rectangle rect) {
        Graphics2D graphics = image.createGraphics();
        graphics.setColor(Color.RED); // Set the rectangle color to red
        graphics.drawRect(rect.x, rect.y, rect.width, rect.height); // Draw the rectangle
        graphics.dispose();
    }

    // Display the image in a window
    public static void showImage(String fileName, String title) {
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        ImageIcon icon = new ImageIcon(fileName);
        JLabel label = new JLabel(icon);
        frame.add(label);

        frame.pack();
        frame.setVisible(true);
    }
}
