package projectPartA;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;
import java.util.List;

public class myMain {

    // Start time to measure the execution duration
    static long initialTimestamp = System.currentTimeMillis();

    // Global variables to hold image data and dimensions
    public static short[][] grayImageMatrix;
    public static int imageWidth;
    public static int imageHeight;
    private static BufferedImage originalImg;
    private static BufferedImage patternImg;
    private static double minDiff = 100000000.0; // Shared minimum value across threads

    public static void main(String[] args) throws IOException {
        // File names for the source and template images
        String originalFilename = "TenCardG.jpg";
        String patternFilename = "Template.jpg";

        // Load the images from files
        File originalFile = new File(originalFilename);
        File patternFile = new File(patternFilename);
        originalImg = ImageIO.read(originalFile);
        patternImg = ImageIO.read(patternFile);

        // Convert images to grayscale
        short[][] originalMatrix = toGrayScaleMatrix(originalFilename);
        short[][] patternMatrix = toGrayScaleMatrix(patternFilename);

        // Number of threads to use for template matching
        int threadCount = 8;

        // Perform multithreaded template matching
        runTemplateMatchingMultithreaded(originalMatrix, patternMatrix, threadCount);

        // Save the result image with rectangles drawn on matches
        String resultFilename = "multithreaded_result.jpg";
        saveImageWithRects(resultFilename);

        System.out.println("Image saved as: " + resultFilename);

        // Verify file existence
        File resultFile = new File(resultFilename);
        if (resultFile.exists()) {
            System.out.println(resultFilename + " has been created.");
        } else {
            System.out.println(resultFilename + " could not be created.");
        }

        // Measure and print the execution time
        long finalTimestamp = System.currentTimeMillis();
        long totalTime = finalTimestamp - initialTimestamp;
        System.out.println("Total execution time: " + totalTime + " milliseconds");
    }

    // Convert an image to a grayscale matrix
    public static short[][] toGrayScaleMatrix(String filename) throws IOException {
        BufferedImage image = ImageIO.read(new File(filename));
        imageWidth = image.getWidth();
        imageHeight = image.getHeight();

        byte[] pixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        grayImageMatrix = new short[imageHeight][imageWidth];

        int pixelIdx, red, green, blue;
        for (int row = 0; row < imageHeight; row++) {
            for (int col = 0; col < imageWidth; col++) {
                pixelIdx = 3 * (row * imageWidth + col);
                red = pixels[pixelIdx] & 0xff;
                green = pixels[pixelIdx + 1] & 0xff;
                blue = pixels[pixelIdx + 2] & 0xff;
                grayImageMatrix[row][col] = (short) Math.round(0.299 * red + 0.587 * green + 0.114 * blue);
            }
        }
        return grayImageMatrix;
    }

    // Multithreaded template matching
    public static void runTemplateMatchingMultithreaded(short[][] originalMatrix, short[][] patternMatrix, int threadCount) {
        int originalHeight = originalMatrix.length;
        int originalWidth = originalMatrix[0].length;
        int patternHeight = patternMatrix.length;
        int patternWidth = patternMatrix[0].length;

        // Split the image into segments for each thread
        int segmentHeight = originalHeight / threadCount;
        List<Thread> threads = new ArrayList<Thread>();

        // Create and start threads for template matching
        for (int i = 0; i < threadCount; i++) {
            int startRow = i * segmentHeight;
            int endRow = (i == threadCount - 1) ? originalHeight : startRow + segmentHeight;
            Thread thread = new Thread(new TemplateMatchTask(startRow, endRow, originalMatrix, patternMatrix, originalImg, patternImg));
            threads.add(thread);
            thread.start();
        }

        // Wait for all threads to finish
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // Save the image with rectangles drawn around matches
    public static void saveImageWithRects(String resultFilename) {
        try {
            ImageIO.write(originalImg, "jpg", new File(resultFilename));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Nested class for template matching task
    static class TemplateMatchTask implements Runnable {
        private final int startRow;
        private final int endRow;
        private final short[][] originalMatrix;
        private final short[][] patternMatrix;
        private final BufferedImage originalImg;
        private final BufferedImage patternImg;

        public TemplateMatchTask(int startRow, int endRow, short[][] originalMatrix, short[][] patternMatrix, BufferedImage originalImg, BufferedImage patternImg) {
            this.startRow = startRow;
            this.endRow = endRow;
            this.originalMatrix = originalMatrix;
            this.patternMatrix = patternMatrix;
            this.originalImg = originalImg;
            this.patternImg = patternImg;
        }

        @Override
        public void run() {
            int originalWidth = originalMatrix[0].length;
            int patternHeight = patternMatrix.length;
            int patternWidth = patternMatrix[0].length;
            int patternArea = patternHeight * patternWidth;

            for (int i = startRow; i <= endRow - patternHeight; i++) {
                for (int j = 0; j <= originalWidth - patternWidth; j++) {
                    double absoluteDiff = 0.0;

                    for (int k = 0; k < patternHeight; k++) {
                        for (int l = 0; l < patternWidth; l++) {
                            absoluteDiff += Math.abs(originalMatrix[i + k][j + l] - patternMatrix[k][l]);
                        }
                    }
                    absoluteDiff /= patternArea;

                    synchronized (myMain.class) {
                        if (absoluteDiff < minDiff) {
                            minDiff = absoluteDiff;
                        }
                    }
                }
            }
        }
    }

    // Draw a rectangle on the image
    public static void drawRectangle(BufferedImage img, int x, int y, int width, int height) {
        Graphics2D graphics = img.createGraphics();
        graphics.setColor(Color.RED);
        graphics.drawRect(x, y, width, height);
        graphics.dispose();
    }
}
