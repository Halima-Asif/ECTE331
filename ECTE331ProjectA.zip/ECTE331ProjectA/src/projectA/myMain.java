package projectA;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;
import java.util.List;

public class myMain {

    public static short[][] grayscaleSourceImage; // 2D array to store grayscale source image data
    public static int sourceWidth;                // Width of the source image
    public static int sourceHeight;               // Height of the source image
    private static BufferedImage sourceImage;     // Source image to search in
    private static BufferedImage templateImage;   // Template image to search for
    private static double minimumAbsDiff = 100000000.0; // Shared minimum value across threads
    private static final Object lock = new Object(); // Custom lock object for synchronization

    public static void main(String[] args) throws IOException {
        String sourceImagePath = "TenCardG.jpg";  // Path to source image
        String templateImagePath = "Template.jpg"; // Path to template image

        // Read the source image and convert to grayscale
        File sourceFile = new File(sourceImagePath);
        sourceImage = ImageIO.read(sourceFile);
        short[][] grayscaleSourceImage = readColourImage(sourceImagePath);

        // Read the template image and convert to grayscale
        File templateFile = new File(templateImagePath);
        templateImage = ImageIO.read(templateFile);
        short[][] grayscaleTemplateImage = readColourImage(templateImagePath);

        // Number of threads to be used in multithreading
        int numberOfThreads = 16;

        // Measure execution time for multithreaded template matching
        long startTime = System.nanoTime();
        templateMatchingMultithreaded(grayscaleSourceImage, grayscaleTemplateImage, numberOfThreads);
        long endTime = System.nanoTime();
        long executionTime = endTime - startTime;

        // Save the result image
        writeColourImage("ResultMultiThreaded.jpg");

        System.out.println("Result image saved as: ResultMultiThreaded.jpg");
        System.out.println("Execution time (Multi-Threaded with " + numberOfThreads + " Threads): " + executionTime / 1000000.0 + " ms");

        // Check if the result file exists
        File resultFile = new File("ResultMultiThreaded.jpg");
        if (resultFile.exists()) {
            System.out.println("ResultMultiThreaded.jpg has been successfully created.");
        } else {
            System.out.println("Failed to create ResultMultiThreaded.jpg.");
        }
    }

    public static short[][] readColourImage(String fileName) throws IOException {
        BufferedImage image = ImageIO.read(new File(fileName));
        sourceWidth = image.getWidth();
        sourceHeight = image.getHeight();

        // Extract pixel data from the image
        byte[] pixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        grayscaleSourceImage = new short[sourceHeight][sourceWidth];

        // Convert pixel data to grayscale values
        int coord, red, green, blue;
        for (int i = 0; i < sourceHeight; i++) {
            for (int j = 0; j < sourceWidth; j++) {
                coord = 3 * (i * sourceWidth + j); // Calculate pixel index
                red = pixels[coord] & 0xff;   // Red component
                green = pixels[coord + 1] & 0xff; // Green component
                blue = pixels[coord + 2] & 0xff; // Blue component

                // Calculate grayscale
                grayscaleSourceImage[i][j] = (short) Math.round(0.299 * red + 0.587 * green + 0.114 * blue);
            }
        }
        return grayscaleSourceImage;
    }

    public static void templateMatchingMultithreaded(final short[][] grayscaleSourceImage, final short[][] grayscaleTemplateImage, int numberOfThreads) {
        int sourceRows = grayscaleSourceImage.length;     // Number of rows in source image
        final int sourceColumns = grayscaleSourceImage[0].length; // Number of columns in source image
        final int templateRows = grayscaleTemplateImage.length;  // Number of rows in template image
        final int templateColumns = grayscaleTemplateImage[0].length; // Number of columns in template image
        final int templateSize = templateRows * templateColumns;   // Total number of pixels in template
        final double[][] absDiffMatrix = new double[sourceRows - templateRows + 1][sourceColumns - templateColumns + 1]; // Matrix to store absolute differences

        // Determine the chunk size for each thread
        int chunkSize = (sourceRows - templateRows + 1) / numberOfThreads;
        final List<int[]> coordinates = new ArrayList<int[]>(); // List to store matching coordinates

        Thread[] threads = new Thread[numberOfThreads]; // Array to store threads

        // Create and start threads
        for (int t = 0; t < numberOfThreads; t++) {
            final int startRow = t * chunkSize; // Start row for the current thread
            final int endRow = (t == numberOfThreads - 1) ? (sourceRows - templateRows + 1) : (startRow + chunkSize); // End row for the current thread

            // Create a new thread
            threads[t] = new Thread(() -> {
                for (int I = startRow; I < endRow; I++) {
                    for (int j = 0; j <= sourceColumns - templateColumns; j++) {
                        double absDiff = 0.0; // Initialize absolute difference

                        // Calculate absolute difference for the current region
                        for (int m = 0; m < templateRows; m++) {
                            for (int n = 0; n < templateColumns; n++) {
                                absDiff += Math.abs(grayscaleSourceImage[I + m][j + n] - grayscaleTemplateImage[m][n]);
                            }
                        }

                        // Normalize the absolute difference
                        absDiff /= templateSize;
                        absDiffMatrix[I][j] = absDiff;

                        // Update the minimum value in a thread-safe manner
                        synchronized (lock) {
                            if (absDiff < minimumAbsDiff) {
                                minimumAbsDiff = absDiff;
                            }
                        }
                    }
                }
            });
            threads[t].start(); // Start the thread
        }

        // Wait for all threads to complete
        try {
            for (Thread thread : threads) {
                thread.join(); // Wait for thread to complete
            }
        } catch (InterruptedException e) {
            e.printStackTrace(); // Print stack trace if interrupted
        }

        // Determine the threshold for a match
        double threshold = 10 * minimumAbsDiff;

        // Identify matching regions based on the threshold
        for (int i = 0; i <= sourceRows - templateRows; i++) {
            for (int j = 0; j <= sourceColumns - templateColumns; j++) {
                if (absDiffMatrix[i][j] <= threshold) {
                    coordinates.add(new int[]{i, j}); // Add matching coordinates to the list
                }
            }
        }

        // Draw rectangles on matching regions in the source image
        for (int[] coord : coordinates) {
            addRectangle(sourceImage, coord[1], coord[0], templateColumns, templateRows);
        }
        
        System.out.println("Number of matches found: " + coordinates.size());
        System.out.println("Coordinates of matches:");
        for (int[] coord : coordinates) {
            System.out.println("Match found at: (" + coord[1] + ", " + coord[0] + ")");
        }
    }

    public static void addRectangle(BufferedImage image, int x, int y, int rectWidth, int rectHeight) {
        Graphics2D g2D = image.createGraphics(); // Get graphics context
        g2D.setColor(Color.RED); // Set color to red
        g2D.drawRect(x, y, rectWidth, rectHeight); // Draw the rectangle
        g2D.dispose(); // Release the graphics context
    }

    public static void writeColourImage(String fileName) throws IOException {
        ImageIO.write(sourceImage, "jpg", new File(fileName)); // Write the image to a file
    }
}
