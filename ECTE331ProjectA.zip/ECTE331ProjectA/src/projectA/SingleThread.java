package projectA;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;
import java.util.List;

public class SingleThread {

    // Global variables to store image data
    public static short[][] grayImage; // Array to store grayscale image data
    public static int width; // Width of the image
    public static int height; // Height of the image
    private static BufferedImage sourceImage; // Original source image
    private static BufferedImage templateImage; // Template image for matching

    public static void main(String[] args) throws IOException {
        // Paths to the source and template images
        String sourceImagePath = "TenCardG.jpg";
        String templateImagePath = "Template.jpg";

        // Read source image and template image
        File sourceFile = new File(sourceImagePath);
        sourceImage = ImageIO.read(sourceFile);
        short[][] sourceImg = readColourImage(sourceImagePath); // Read source image as grayscale

        File templateFile = new File(templateImagePath);
        templateImage = ImageIO.read(templateFile);
        short[][] templateImg = readColourImage(templateImagePath); // Read template image as grayscale

        // Perform template matching
        templateMatching(sourceImg, templateImg);

        // Save the result image
        writeColourImage("Result.jpg");
        System.out.println("Result image saved as: Result.jpg");

        // Verify if the result image has been successfully created
        File resultFile = new File("Result.jpg");
        if (resultFile.exists()) {
            System.out.println("Result.jpg has been successfully created.");
        } else {
            System.out.println("Failed to create Result.jpg.");
        }
    }

    // Method to read a color image and convert it to grayscale
    public static short[][] readColourImage(String fileName) throws IOException {
        BufferedImage image = ImageIO.read(new File(fileName));
        width = image.getWidth(); // Get width of the image
        height = image.getHeight(); // Get height of the image

        // Get byte array of pixels from the image
        byte[] pixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        grayImage = new short[height][width]; // Initialize grayscale image array

        int coord, pr, pg, pb;
        // Convert each pixel to grayscale 
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                coord = 3 * (i * width + j); // Calculate coordinate in the byte array
                pr = pixels[coord] & 0xff; // Red component
                pg = pixels[coord + 1] & 0xff; // Green component
                pb = pixels[coord + 2] & 0xff; // Blue component
                // Calculate grayscale 
                grayImage[i][j] = (short) Math.round(0.299 * pr + 0.587 * pg + 0.114 * pb);
            }
        }
        return grayImage; // Return grayscale image array
    }

    // Method to perform template matching and draw rectangles on the source image
    public static void templateMatching(short[][] sourceImg, short[][] templateImg) {
        int r1 = sourceImg.length; // Rows of source image
        int c1 = sourceImg[0].length; // Columns of source image
        int r2 = templateImg.length; // Rows of template image
        int c2 = templateImg[0].length; // Columns of template image
        int tempSize = r2 * c2; // Size of template

        double minimum = 100000000; // Initialize minimum difference to a large number
        double[][] absDiffMat = new double[r1 - r2 + 1][c1 - c2 + 1]; // Matrix to store absolute differences

        // Calculate absolute differences and find minimum
        for (int i = 0; i <= r1 - r2; i++) {
            for (int j = 0; j <= c1 - c2; j++) {
                double absDiff = 0.0;
                // Compute sum of absolute differences for current template position
                for (int m = 0; m < r2; m++) {
                    for (int n = 0; n < c2; n++) {
                        absDiff += Math.abs(sourceImg[i + m][j + n] - templateImg[m][n]);
                    }
                }
                absDiff /= tempSize; // Normalize by template size
                absDiffMat[i][j] = absDiff; // Store the normalized difference

                // Update minimum difference
                if (absDiff < minimum) {
                    minimum = absDiff;
                }
            }
        }

        // Set threshold for matching
        double threshold = 10 * minimum;

        // Store coordinates of matches below the threshold
        List<int[]> coordinates = new ArrayList<int[]>();
        for (int i = 0; i <= r1 - r2; i++) {
            for (int j = 0; j <= c1 - c2; j++) {
                if (absDiffMat[i][j] <= threshold) {
                    coordinates.add(new int[]{i, j}); // Add coordinates to the list
                }
            }
        }

        // Draw rectangles at matched coordinates on the source image
        for (int[] coord : coordinates) {
            addRectangle(sourceImage, coord[1], coord[0], c2, r2); // Draw rectangle at each coordinate
        }
    }

    // Method to draw a rectangle on an image
    public static void addRectangle(BufferedImage image, int x, int y, int rectWidth, int rectHeight) {
        Graphics2D g2D = image.createGraphics(); // Create graphics context
        g2D.setColor(Color.RED); // Set rectangle color
        g2D.drawRect(x, y, rectWidth, rectHeight); // Draw rectangle
        g2D.dispose(); // Release graphics resources
    }

    // Method to write a color image to file
    public static void writeColourImage(String fileName) throws IOException {
        ImageIO.write(sourceImage, "jpg", new File(fileName)); // Write image to file
    }
}
