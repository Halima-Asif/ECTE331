package ECTE3331_Project_B;

// Class representing the main task
public class task {
	public static void main(String[] args) throws InterruptedException { // MAIN method
		
		Data my_sample = new Data(); // Creating an instance of the Data class
		int test_size = 3; // Define the number of test iterations
		
		for(int i=0; i<test_size; i++) { // Loop to run the test multiple times
			System.out.println("Try: " + i);
			
			// Resetting flags for synchronization between threads
			my_sample.goB2 = false;
			my_sample.goB3 = false;
			my_sample.goA2 = false;
			my_sample.goA3 = false;
			
			// Creating instances of ThreadA and ThreadB
			ThreadA t_a = new ThreadA(my_sample);
			ThreadB t_b = new ThreadB(my_sample);
			
			// Starting both threads
			t_a.start();
			t_b.start();
			// Ensuring main thread waits for ThreadA and ThreadB to finish
			t_a.join();
			t_b.join();
		}
	}
}

// Class that stores all the variables and boolean flags used for synchronization
class Data {
	int A1, A2, A3, B1, B2, B3;
	boolean goA1 = false;
	boolean goA2 = false;
	boolean goA3 = false;
	boolean goB1 = false;
	boolean goB2 = false;
	boolean goB3 = false;
}

// Class representing ThreadA
class ThreadA extends Thread {
	private Data sample; // Reference to the shared Data object

	public ThreadA(Data sample) { // Constructor to initialize the shared Data object
		this.sample = sample;
	}

	public void run() {
		synchronized (sample) { // Function A1
			int n = 500;
			sample.A1 = n * (n + 1) / 2; // Calculate sum of first 500 natural numbers
			System.out.println("A1= " + sample.A1);
			sample.goB2 = true; // Set flag to indicate A1 is done
			sample.notify(); // Notify other waiting threads
		}

		synchronized (sample) {
			while (!sample.goA2) { // Wait for B2 to complete
				try {
					sample.wait();
					System.out.println("System is waiting for B2 value");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		synchronized (sample) {
			if (sample.goA2) { // Function A2
				int n = 300;
				sample.A2 = sample.B2 + n * (n + 1) / 2; // Calculate based on B2
				System.out.println("A2= " + sample.A2);
				sample.goB3 = true; // Set flag to indicate A2 is done
				sample.notify(); // Notify other waiting threads
			}
		}

		synchronized (sample) {
			while (!sample.goA3) { // Wait for B3 to complete
				try {
					sample.wait();
					System.out.println("System is waiting for B3 value");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		synchronized (sample) {
			if (sample.goA3) { // Function A3
				int n = 400;
				sample.A3 = sample.B3 + n * (n + 1) / 2; // Calculate based on B3
				System.out.println("A3= " + sample.A3);
			}
		}
	}
}

// Class representing ThreadB
class ThreadB extends Thread {
	private Data sample; // Reference to the shared Data object

	public ThreadB(Data sample) { // Constructor to initialize the shared Data object
		this.sample = sample;
	}

	public void run() {
		synchronized (sample) { // Function B1
			int n = 250;
			sample.B1 = n * (n + 1) / 2; // Calculate sum of first 250 natural numbers
			System.out.println("B1= " + sample.B1);
		}

		synchronized (sample) {
			while (!sample.goB2) { // Wait for A1 to complete
				try {
					sample.wait();
					System.out.println("System is waiting for A1 value");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		synchronized (sample) {
			if (sample.goB2) { // Function B2
				int n = 200;
				sample.B2 = sample.A1 + n * (n + 1) / 2; // Calculate based on A1
				System.out.println("B2= " + sample.B2);
				sample.goA2 = true; // Set flag to indicate B2 is done
				sample.notify(); // Notify other waiting threads
			}
		}

		synchronized (sample) {
			while (!sample.goB3) { // Wait for A2 to complete
				try {
					sample.wait();
					System.out.println("System is waiting for A2 value");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		synchronized (sample) {
			if (sample.goB3) { // Function B3
				int n = 400;
				sample.B3 = sample.A2 + n * (n + 1) / 2; // Calculate based on A2
				System.out.println("B3= " + sample.B3);
				sample.goA3 = true; // Set flag to indicate B3 is done
				sample.notify(); // Notify other waiting threads
			}
		}
	}
}
